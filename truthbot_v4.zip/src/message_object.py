
class MessageObject:
    def __init__(self, text):
        self.text = text

    def get_sentiment(self):
        return 0.0

    def detect_rhetorical_devices(self):
        return []

    def extract_keywords(self):
        return []

    def moral_framing_analysis(self):
        return 0.0

    def calculate_linguistic_drift(self):
        return 0.0
