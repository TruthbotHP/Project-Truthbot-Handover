
# test_run_truthbot_school.py

import json
from mooc_ingestion.ingest_engine import MOOCIngestionEngine

def main():
    engine = MOOCIngestionEngine()
    valid_courses, rejected_courses = engine.run_full_ingestion()

    # Save validated curriculum
    with open("logs/curriculum.json", "w") as f:
        json.dump(valid_courses, f, indent=2)

    # Save rejected courses
    with open("logs/truth_reject_log.json", "w") as f:
        json.dump({"rejected": rejected_courses}, f, indent=2)

    print(f"Ingested {len(valid_courses)} valid and {len(rejected_courses)} rejected courses.")
    print("Logs updated.")

if __name__ == "__main__":
    main()
