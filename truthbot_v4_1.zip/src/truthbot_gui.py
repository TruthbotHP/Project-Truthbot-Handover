
import sys
from PyQt5 import QtWidgets
from truthbot_core import TruthBotCore

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.core = TruthBotCore({'log_level':'DEBUG'})
        self.setWindowTitle('TruthBot v4')
        self.text_edit = QtWidgets.QTextEdit()
        self.setCentralWidget(self.text_edit)
        toolbar = self.addToolBar('Main')
        analyze_btn = QtWidgets.QPushButton('Analyze')
        analyze_btn.clicked.connect(self.run_analysis)
        toolbar.addWidget(analyze_btn)
        # Feature toggles
        self.assump_chk = QtWidgets.QCheckBox('Assumption Cascade')
        self.extli_chk = QtWidgets.QCheckBox('Extended LI Metrics')
        toolbar.addWidget(self.assump_chk)
        toolbar.addWidget(self.extli_chk)
        # Add Admin menu
        menubar = self.menuBar()
        adminMenu = menubar.addMenu('Admin')
        from src.admin_gui import AdminDashboard
        dashAct = QtWidgets.QAction('Dashboard', self)
        dashAct.triggered.connect(lambda: AdminDashboard(self).exec_())
        adminMenu.addAction(dashAct)

    def run_analysis(self):
        text = self.text_edit.toPlainText()
        features = []
        if self.assump_chk.isChecked():
            features.append('assumption_cascade')
        if self.extli_chk.isChecked():
            features.append('extended_li')
        results = self.core.analyze_text(text, features)
        QtWidgets.QMessageBox.information(self, 'Results', str(results))

if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    mw = MainWindow()
    mw.show()
    sys.exit(app.exec_())
