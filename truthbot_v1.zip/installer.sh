
#!/bin/bash
python3 -m venv truthbot_env
source truthbot_env/bin/activate
pip install -r requirements.txt
python3 - <<EOF
from truthbot_core import TruthBotCore
print('Self-test:', TruthBotCore({'log_level':'INFO'}).analyze_text('Test'))
EOF
