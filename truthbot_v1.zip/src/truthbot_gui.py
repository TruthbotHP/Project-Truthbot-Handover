
from PyQt5 import QtWidgets
from truthbot_core import TruthBotCore

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, core):
        super().__init__()
        self.core = core
        self.setWindowTitle('TruthBot')
        self.text_edit = QtWidgets.QTextEdit(self)
        self.setCentralWidget(self.text_edit)
        button = QtWidgets.QPushButton('Analyze', self)
        button.clicked.connect(self.run_analysis)
        toolbar = self.addToolBar('Main')
        toolbar.addWidget(button)

    def run_analysis(self):
        text = self.text_edit.toPlainText()
        results = self.core.analyze_text(text)
        QtWidgets.QMessageBox.information(self, 'Results', str(results))

if __name__ == '__main__':
    import sys
    config = {'log_level': 'DEBUG'}
    core = TruthBotCore(config)
    app = QtWidgets.QApplication(sys.argv)
    mw = MainWindow(core)
    mw.show()
    sys.exit(app.exec_())
