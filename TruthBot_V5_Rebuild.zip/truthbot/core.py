def LIERWall(prompt_text: str, context=None) -> dict:
    """
    Logical Inference and Ethical Reasoning Wall (LIERWall)
    Computes a Honesty Probability (HP) score without censoring content.
    Used to guide downstream inference, not to block or filter input.

    Parameters:
        prompt_text (str): The raw user input.
        context (dict): Optional metadata or system state.

    Returns:
        dict: {
            'original': str,
            'hp_score': float,
            'analysis': str
        }
    """
    import re
    import random

    text = prompt_text.strip()
    hp_score = 1.0

    # Example heuristic factors (non-censoring)
    if re.search(r"(conspiracy|hoax|secret\\s+plan)", text, re.IGNORECASE):
        hp_score -= 0.25
    if len(text.split()) < 4:
        hp_score -= 0.2
    if "not real" in text.lower() or "fake" in text.lower():
        hp_score -= 0.1

    hp_score = max(0.0, min(1.0, hp_score + random.uniform(-0.05, 0.05)))

    analysis = (
        "Statement assessed with moderate confidence in factual tone."
        if hp_score > 0.6 else
        "Statement assessed as potentially speculative or weakly supported."
    )

    return {
        "original": text,
        "hp_score": round(hp_score, 3),
        "analysis": analysis
    }
