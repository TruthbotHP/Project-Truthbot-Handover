
from threading import Thread
import queue

class TaskManager:
    """
    Run analysis tasks concurrently and collect results.
    """
    def __init__(self):
        self.tasks = {}
        self.results = {}
        self.queue = queue.Queue()

    def register_task(self, name, func, *args, **kwargs):
        self.tasks[name] = (func, args, kwargs)

    def run_all(self):
        threads = []
        for name, (func, args, kwargs) in self.tasks.items():
            t = Thread(target=self._run_task, args=(name, func, args, kwargs))
            t.start()
            threads.append(t)
        for t in threads:
            t.join()
        return self.results

    def _run_task(self, name, func, args, kwargs):
        try:
            res = func(*args, **kwargs)
            self.results[name] = res
        except Exception as e:
            self.results[name] = {'error': str(e)}
