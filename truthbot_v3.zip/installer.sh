
#!/bin/bash
python3 -m venv truthbot_env
source truthbot_env/bin/activate

# Install wheels if present
if [ -d wheels ]; then
    pip install wheels/*.whl
fi
pip install -r requirements.txt

# Copy NLTK data
if [ -d nltk_data ]; then
    mkdir -p truthbot_env/nltk_data
    cp -r nltk_data/* truthbot_env/nltk_data/
    export NLTK_DATA=$(pwd)/truthbot_env/nltk_data
fi

# Post-install diagnostic and auto-repair
python3 - <<EOF
from src.truthbot_core import TruthBotCore
core = TruthBotCore({'log_level':'INFO'})
issues = core.issues
print('Initial issues:', issues)
if issues:
    print('Attempting auto-repair...')
    remaining = core.repair_environment()
    print('Remaining issues:', remaining)
EOF
