
import os
import shutil
import logging
from truthbot_core import check_environment

class SelfRepairAgent:
    """
    Detects environment issues and applies offline fixes automatically.
    """
    def __init__(self, base_path):
        self.base_path = base_path
        logging.debug(f"SelfRepairAgent initialized at {base_path}")

    def repair(self):
        issues = check_environment()
        if not issues:
            logging.info("No issues detected; repair not needed.")
            return issues
        logging.warning(f"Issues detected: {issues}")
        for issue in issues:
            if "Missing NLTK punkt tokenizer" in issue:
                self._bundle_nltk_data()
            elif "Missing PyQt5 GUI package" in issue:
                logging.info("PyQt5 missing: please place wheel in wheels/ and re-run installer.")
        # Re-run environment check after attempts
        new_issues = check_environment()
        if not new_issues:
            logging.info("Repair succeeded, no remaining issues.")
        else:
            logging.error(f"Remaining issues after repair: {new_issues}")
        return new_issues

    def _bundle_nltk_data(self):
        src = os.path.join(self.base_path, 'nltk_data', 'tokenizers', 'punkt')
        dst = os.path.join(self.base_path, 'src', '..', 'nltk_data', 'tokenizers', 'punkt')
        if os.path.isdir(src):
            try:
                shutil.copytree(src, dst, dirs_exist_ok=True)
                logging.info("Bundled NLTK punkt data into environment.")
            except Exception as e:
                logging.error(f"Failed to bundle NLTK data: {e}")
        else:
            logging.error("No bundled nltk_data/tokenizers/punkt found to install.")
