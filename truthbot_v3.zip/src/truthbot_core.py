
import os
import json
import logging
import nltk
import re
from repair_agent import SelfRepairAgent

# Set NLTK data path relative to package
NLTK_DATA_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'nltk_data'))
os.environ.setdefault('NLTK_DATA', NLTK_DATA_PATH)

def check_environment():
    """
    Pre-flight check for key offline resources:
      - NLTK punkt tokenizer
      - PyQt5 GUI package
    Logs any missing items to logs/install_issues.log.
    Returns a list of issue messages.
    """
    issues = []
    try:
        nltk.data.find('tokenizers/punkt')
    except LookupError:
        issues.append('Missing NLTK punkt tokenizer')
    try:
        import PyQt5  # noqa: F401
    except ImportError:
        issues.append('Missing PyQt5 GUI package')
    log_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'logs'))
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, 'install_issues.log')
    with open(log_path, 'w') as log_file:
        for issue in issues:
            log_file.write(issue + '\n')
    return issues

class TruthBotCore:
    def __init__(self, config):
        log_level = config.get('log_level', 'INFO')
        logging.basicConfig(level=getattr(logging, log_level))
        self.base_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
        # Pre-flight checks and optional self-repair
        self.issues = check_environment()
        self.repair_agent = SelfRepairAgent(self.base_path)
        if self.issues:
            logging.warning(f"Environment issues: {self.issues}")
    def repair_environment(self):
        """
        Invoke SelfRepairAgent to attempt automated fixes.
        """
        return self.repair_agent.repair()
    # ... existing analyze_text, compute_li_e1, compute_li_o1, etc. ...
