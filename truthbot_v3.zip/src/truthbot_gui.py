
import sys
try:
    from PyQt5 import QtWidgets
    GUI_AVAILABLE = True
except ImportError:
    GUI_AVAILABLE = False
from truthbot_core import TruthBotCore

def run_cli(core):
    print('CLI mode. Enter text (empty to exit):')
    while True:
        text = input('> ')
        if not text.strip():
            break
        print('Results:', core.analyze_text(text))

if GUI_AVAILABLE:
    class MainWindow(QtWidgets.QMainWindow):
        def __init__(self, core):
            super().__init__()
            self.core = core
            self.setWindowTitle('TruthBot')
            self.text_edit = QtWidgets.QTextEdit(self)
            self.setCentralWidget(self.text_edit)
            # Toolbar actions
            analyze_btn = QtWidgets.QPushButton('Analyze', self)
            analyze_btn.clicked.connect(self.run_analysis)
            repair_btn = QtWidgets.QPushButton('Repair Environment', self)
            repair_btn.clicked.connect(self.run_repair)
            toolbar = self.addToolBar('Main')
            toolbar.addWidget(analyze_btn)
            toolbar.addWidget(repair_btn)
        def run_analysis(self):
            results = self.core.analyze_text(self.text_edit.toPlainText())
            QtWidgets.QMessageBox.information(self, 'Results', str(results))
        def run_repair(self):
            issues = self.core.repair_environment()
            QtWidgets.QMessageBox.information(self, 'Repair Results', '\n'.join(issues) or 'No issues remaining.')
    def launch_gui(core):
        app = QtWidgets.QApplication(sys.argv)
        mw = MainWindow(core)
        mw.show()
        sys.exit(app.exec_())
else:
    def launch_gui(core):
        print('GUI unavailable; using CLI fallback.')
        run_cli(core)

if __name__ == '__main__':
    config = {'log_level': 'DEBUG'}
    core = TruthBotCore(config)
    launch_gui(core)
