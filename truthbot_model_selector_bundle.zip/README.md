# TruthBot Model Selector Edition

Supports:
- Mistral, Phi, TinyLLaMA models
- GPT4All fallback
- GUI dropdown for model selection
- CLI with --model flag

Example:
    truthbot-cli --text "Example input" --model phi

GUI:
    truthbot-gui
