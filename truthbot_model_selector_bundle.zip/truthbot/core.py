import os
import nltk
import spacy
import requests
from llama_cpp import Llama
from nltk.sentiment import SentimentIntensityAnalyzer

nltk.download("vader_lexicon", quiet=True)
nlp = spacy.load("en_core_web_md")

MODEL_MAP = {
    "mistral": "C:/Models/mistral-7b-instruct.Q4_K_M.gguf",
    "phi": "C:/Models/phi-2.Q4_K_M.gguf",
    "tiny": "C:/Models/tinyllama.Q4_K_M.gguf"
}

class TruthBotCore:
    def __init__(self, model_name="mistral"):
        self.model_name = model_name
        self.model_path = MODEL_MAP.get(model_name, MODEL_MAP["mistral"])
        self.sia = SentimentIntensityAnalyzer()
        try:
            self.llm = Llama(model_path=self.model_path, n_ctx=2048)
        except Exception as e:
            print(f"Falling back: failed to load model {model_name}: {e}")
            self.llm = None

    def analyze_text(self, text):
        sent = self.sia.polarity_scores(text)
        doc = nlp(text)
        entities = [(ent.text, ent.label_) for ent in doc.ents]
        hedges = {"maybe", "possibly", "perhaps", "could"}
        hedge_ratio = sum(w.lower() in hedges for w in text.split()) / max(len(text.split()), 1)
        return {"sentiment": sent, "entities": entities, "hedge_ratio": round(hedge_ratio, 3)}

    def analyze_with_model(self, text):
        prompt = f"Analyze this text for truthfulness and bias:

{text}

Analysis:"
        if self.llm:
            try:
                result = self.llm(prompt, max_tokens=256, stop=["\n\n"])
                return result["choices"][0]["text"].strip()
            except Exception as e:
                print(f"Model error: {e}")
        return self.analyze_with_gpt4all(text)

    def analyze_with_gpt4all(self, text):
        try:
            response = requests.post("http://localhost:4891/v1/chat/completions", json={
                "model": "mistral-7b",
                "messages": [
                    {"role": "system", "content": "You are a truthfulness analyst."},
                    {"role": "user", "content": text}
                ],
                "temperature": 0.7
            })
            return response.json()["choices"][0]["message"]["content"]
        except Exception as e:
            return f"GPT4All fallback failed: {e}"
