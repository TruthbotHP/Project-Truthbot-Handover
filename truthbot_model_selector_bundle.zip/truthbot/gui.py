import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QComboBox, QTextEdit, QPushButton, QLabel, QMainWindow, QTabWidget
from truthbot.core import TruthBotCore

class Agent(QWidget):
    def __init__(self):
        super().__init__()
        self.layout = QVBoxLayout()
        self.model_select = QComboBox()
        self.model_select.addItems(["mistral", "phi", "tiny"])
        self.input = QTextEdit()
        self.analyze_btn = QPushButton("Analyze")
        self.output = QLabel()
        self.layout.addWidget(self.model_select)
        self.layout.addWidget(self.input)
        self.layout.addWidget(self.analyze_btn)
        self.layout.addWidget(self.output)
        self.setLayout(self.layout)
        self.analyze_btn.clicked.connect(self.run)

    def run(self):
        model = self.model_select.currentText()
        text = self.input.toPlainText()
        bot = TruthBotCore(model_name=model)
        out = bot.analyze_with_model(text)
        self.output.setText(out)

class TruthBotGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("TruthBot Multi-Agent GUI")
        self.setGeometry(100, 100, 800, 600)
        self.tabs = QTabWidget()
        for i in range(3):
            self.tabs.addTab(Agent(), f"Agent {i+1}")
        self.setCentralWidget(self.tabs)

def main():
    app = QApplication(sys.argv)
    win = TruthBotGUI()
    win.show()
    sys.exit(app.exec_())
