import argparse
from truthbot.core import TruthBotCore

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--text", type=str, required=True)
    parser.add_argument("--model", type=str, default="mistral")
    args = parser.parse_args()
    bot = TruthBotCore(model_name=args.model)
    result = bot.analyze_with_model(args.text)
    print(result)
