from setuptools import setup, find_packages

setup(
    name="truthbot-model-selector",
    version="0.4.0",
    packages=find_packages(),
    install_requires=[
        "llama-cpp-python",
        "requests",
        "PyQt5",
        "nltk",
        "spacy",
        "pandas",
        "numpy"
    ],
    entry_points={
        "console_scripts": [
            "truthbot-cli=truthbot.cli:main",
            "truthbot-gui=truthbot.gui:main"
        ],
    },
)
