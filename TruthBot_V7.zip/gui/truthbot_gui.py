
import tkinter as tk
from tkinter import messagebox
from core import hardware

def launch_diagnostics():
    specs = hardware.detect_capabilities()
    msg = "\n".join([f"{k}: {v}" for k, v in specs.items()])
    messagebox.showinfo("System Capabilities", msg)

def model_suggestion():
    suggestions = hardware.recommend_models()
    messagebox.showinfo("Model Suggestions", "\n".join(suggestions))

root = tk.Tk()
root.title("TruthBot V7 GUI")
root.geometry("400x300")

tk.Label(root, text="TruthBot V7 Control Panel", font=("Arial", 14)).pack(pady=10)
tk.Button(root, text="Run System Diagnostic", command=launch_diagnostics).pack(pady=10)
tk.Button(root, text="Model Recommendations", command=model_suggestion).pack(pady=10)
tk.Button(root, text="Exit", command=root.destroy).pack(pady=10)

root.mainloop()
