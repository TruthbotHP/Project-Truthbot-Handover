
import importlib.util
import os

def load_plugins(path='llm_plugins'):
    plugins = {}
    for fname in os.listdir(path):
        if fname.endswith(".py"):
            name = fname[:-3]
            spec = importlib.util.spec_from_file_location(name, os.path.join(path, fname))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            plugins[name] = mod
    return plugins
