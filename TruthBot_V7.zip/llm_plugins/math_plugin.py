def solve_math(prompt):
    try:
        return eval(prompt)
    except:
        return "Invalid math expression"