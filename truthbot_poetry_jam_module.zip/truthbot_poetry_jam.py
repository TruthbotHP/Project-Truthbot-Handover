# truthbot_poetry_jam.py
import random

# Placeholder scoring logic
def hp_score_line(line):
    if any(word in line.lower() for word in ["truth", "care", "open", "listen", "heal"]):
        return round(random.uniform(0.7, 1.0), 2)
    elif any(word in line.lower() for word in ["obey", "power", "silent", "submit"]):
        return round(random.uniform(0.1, 0.4), 2)
    else:
        return round(random.uniform(0.4, 0.7), 2)

def tribe_reflection(line, tribe="empath"):
    if tribe == "empath":
        if "grief" in line or "loss" in line:
            return "⚠️ Resonant sorrow detected"
        elif "hope" in line:
            return "💖 Shared light"
    elif tribe == "analyst":
        if "truth" in line:
            return "🧠 Verified logic node"
        if "dream" in line:
            return "❓ Abstract — caution flagged"
    elif tribe == "seer":
        if "myth" in line or "symbol" in line:
            return "🌀 Archival meaning sensed"
    return "⋯ Reflection pending"

# Call this in a loop for poetic back-and-forth
def play_poetry_turn(line, tribe="empath"):
    score = hp_score_line(line)
    feedback = tribe_reflection(line, tribe)
    return {"line": line, "hp_score": score, "reflection": feedback}