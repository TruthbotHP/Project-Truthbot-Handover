
import tkinter as tk
from tkinter import scrolledtext
from core.lierwall import LIERWall

class TruthBotChatGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("TruthBot V7.1 - HP Evaluator Chat")

        self.chat_display = scrolledtext.ScrolledText(root, width=80, height=20, state='disabled')
        self.chat_display.pack(padx=10, pady=10)

        self.input_field = tk.Entry(root, width=80)
        self.input_field.pack(padx=10, pady=(0, 10))
        self.input_field.bind("<Return>", self.process_input)

        self.hp_label = tk.Label(root, text="HP Score: N/A")
        self.hp_label.pack(pady=(0, 10))

    def process_input(self, event):
        user_input = self.input_field.get()
        self.input_field.delete(0, tk.END)

        # Pass through LIERWall for HP logic (placeholder logic here)
        response = LIERWall(user_input)

        # Simulate HP score extraction (can be replaced with real ML logic)
        hp_score = self.estimate_hp(user_input)

        self.chat_display.config(state='normal')
        self.chat_display.insert(tk.END, f"You: {user_input}\n")
        self.chat_display.insert(tk.END, f"TruthBot (HP: {hp_score}%): {response}\n\n")
        self.chat_display.config(state='disabled')
        self.chat_display.yview(tk.END)

        self.hp_label.config(text=f"HP Score: {hp_score}%")

    def estimate_hp(self, text):
        # Placeholder HP scoring - replace with real model
        if "truth" in text.lower():
            return 90
        elif "maybe" in text.lower():
            return 60
        elif "lie" in text.lower():
            return 30
        return 70

if __name__ == "__main__":
    root = tk.Tk()
    app = TruthBotChatGUI(root)
    root.mainloop()
