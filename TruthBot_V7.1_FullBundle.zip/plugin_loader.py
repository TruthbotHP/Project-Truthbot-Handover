
import os
import importlib.util

PLUGIN_DIR = os.path.join(os.path.dirname(__file__), "llm_plugins")

def load_plugins():
    plugins = {}
    for filename in os.listdir(PLUGIN_DIR):
        if filename.endswith(".py") and not filename.startswith("__"):
            plugin_name = filename[:-3]
            file_path = os.path.join(PLUGIN_DIR, filename)
            spec = importlib.util.spec_from_file_location(plugin_name, file_path)
            module = importlib.util.module_from_spec(spec)
            try:
                spec.loader.exec_module(module)
                plugins[plugin_name] = module
            except Exception as e:
                print(f"Error loading plugin {plugin_name}: {e}")
    return plugins

if __name__ == "__main__":
    plugins = load_plugins()
    print("Loaded plugins:", list(plugins.keys()))
