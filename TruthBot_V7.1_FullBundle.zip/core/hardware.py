
import platform
import psutil

def detect_capabilities():
    return {
        "OS": platform.system(),
        "OS Version": platform.version(),
        "CPU": platform.processor(),
        "CPU Cores": psutil.cpu_count(logical=False),
        "Logical CPUs": psutil.cpu_count(logical=True),
        "RAM (GB)": round(psutil.virtual_memory().total / (1024 ** 3), 2)
    }

def recommend_models():
    specs = detect_capabilities()
    recs = []
    ram = specs.get("RAM (GB)", 4)
    if ram < 6:
        recs.append("Recommend TinyLLaMA or Phi-2 (~1-3B models)")
    elif ram < 12:
        recs.append("Recommend Mistral-7B or Phi-2")
    else:
        recs.append("Capable of running Mixtral, LLaMA2 13B or higher (GGUF recommended)")
    recs.append("Search: site:huggingface.co model_name gguf")
    return recs
