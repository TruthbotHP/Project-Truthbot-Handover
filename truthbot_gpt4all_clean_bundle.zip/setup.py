from setuptools import setup, find_packages

setup(
    name="truthbot-gpt4all",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "requests",
        "PyQt5",
        "nltk",
        "spacy",
        "pandas",
        "numpy"
    ],
    entry_points={
        "console_scripts": [
            "truthbot-cli=truthbot.cli:main",
            "truthbot-gui=truthbot.gui:main"
        ],
    },
)
