# TruthBot GPT4All-Only Edition

## Features
- Uses GPT4All local API (http://localhost:4891)
- No llama-cpp or C++ compiler needed
- Lightweight, easy to install

## Usage

### CLI:
truthbot-cli --text "Is this honest?"

### GUI:
truthbot-gui
