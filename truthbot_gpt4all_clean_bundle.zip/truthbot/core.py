import nltk
import spacy
import requests
from nltk.sentiment import SentimentIntensityAnalyzer

nltk.download("vader_lexicon", quiet=True)
nlp = spacy.load("en_core_web_md")

class TruthBotCore:
    def __init__(self):
        self.sia = SentimentIntensityAnalyzer()

    def analyze_text(self, text):
        sent = self.sia.polarity_scores(text)
        doc = nlp(text)
        entities = [(ent.text, ent.label_) for ent in doc.ents]
        hedges = {"maybe", "possibly", "perhaps", "could"}
        hedge_ratio = sum(w.lower() in hedges for w in text.split()) / max(len(text.split()), 1)
        return {"sentiment": sent, "entities": entities, "hedge_ratio": round(hedge_ratio, 3)}

    def analyze_with_model(self, text):
        try:
            response = requests.post("http://localhost:4891/v1/chat/completions", json={
                "model": "mistral-7b",
                "messages": [
                    {"role": "system", "content": "You are a truthfulness analyst."},
                    {"role": "user", "content": text}
                ],
                "temperature": 0.7
            })
            return response.json()["choices"][0]["message"]["content"]
        except Exception as e:
            return f"[GPT4All failed] {e}"
