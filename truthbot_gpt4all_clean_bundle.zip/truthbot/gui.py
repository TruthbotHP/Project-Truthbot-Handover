import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QTextEdit, QPushButton, QLabel, QMainWindow
from truthbot.core import TruthBotCore

class TruthBotApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("TruthBot GPT4All")
        self.setGeometry(100, 100, 800, 600)

        widget = QWidget()
        layout = QVBoxLayout()

        self.input = QTextEdit()
        self.button = QPushButton("Analyze")
        self.output = QLabel()

        layout.addWidget(self.input)
        layout.addWidget(self.button)
        layout.addWidget(self.output)
        widget.setLayout(layout)
        self.setCentralWidget(widget)

        self.core = TruthBotCore()
        self.button.clicked.connect(self.analyze)

    def analyze(self):
        text = self.input.toPlainText()
        result = self.core.analyze_with_model(text)
        self.output.setText(result)

def main():
    app = QApplication(sys.argv)
    win = TruthBotApp()
    win.show()
    sys.exit(app.exec_())
