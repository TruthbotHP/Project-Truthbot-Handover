import argparse
from truthbot.core import TruthBotCore

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--text", type=str, required=True)
    args = parser.parse_args()
    bot = TruthBotCore()
    result = bot.analyze_with_model(args.text)
    print(result)
