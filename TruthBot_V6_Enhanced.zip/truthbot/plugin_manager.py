
import os
import importlib.util

PLUGIN_DIR = os.path.join(os.path.dirname(__file__), 'llm_plugins')

def load_plugins():
    plugins = {}
    for filename in os.listdir(PLUGIN_DIR):
        if filename.endswith(".py"):
            mod_name = filename[:-3]
            file_path = os.path.join(PLUGIN_DIR, filename)
            spec = importlib.util.spec_from_file_location(mod_name, file_path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            plugins[mod_name] = mod
    return plugins
