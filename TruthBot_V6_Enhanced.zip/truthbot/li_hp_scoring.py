
def score_hp(prompt: str) -> float:
    """Fake scoring function: returns float representing honesty probability."""
    if 'not' in prompt or 'never' in prompt:
        return 0.3
    return 0.85

def apply_hp_filter(prompt: str, min_score=0.5):
    score = score_hp(prompt)
    return {"hp_score": score, "prompt": prompt, "pass": score >= min_score}
