
import sys
from truthbot.utils import run_diagnostic_pass
from truthbot.llm_plugins import sentiment_plugin, math_plugin, qa_plugin

def launch():
    print("=== TruthBot Launching ===")
    diag = run_diagnostic_pass()
    print("System Diagnostics:", diag)

    # Sample prompt flow
    print("\nSentiment Check:", sentiment_plugin.analyze_sentiment("I love TruthBot!"))
    print("Math Solver:", math_plugin.solve_math("2 + 2 * 10"))
    print("Q&A Response:", qa_plugin.answer_question("What is TruthBot?"))

if __name__ == "__main__":
    launch()
