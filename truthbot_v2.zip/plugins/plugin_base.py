
class PluginInterface:
    def analyze(self, text):
        raise NotImplementedError
