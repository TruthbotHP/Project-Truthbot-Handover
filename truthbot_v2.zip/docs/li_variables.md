# LI Variables Documentation

Detailed docs here.