
#!/bin/bash
# Create virtual environment
python3 -m venv truthbot_env
source truthbot_env/bin/activate

# Install local wheels first (e.g., PyQt5)
if [ -d wheels ]; then
    pip install wheels/*.whl
fi

# Install other requirements
pip install -r requirements.txt

# Copy bundled NLTK data into environment
if [ -d nltk_data ]; then
    mkdir -p truthbot_env/nltk_data
    cp -r nltk_data/* truthbot_env/nltk_data/
    export NLTK_DATA=$(pwd)/truthbot_env/nltk_data
fi

# Run post-install diagnostic
python3 - <<EOF
from truthbot_core import TruthBotCore
issues = TruthBotCore({'log_level':'INFO'}).issues
print('Post-install issues:', issues)
EOF
