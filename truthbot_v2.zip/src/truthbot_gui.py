
import sys

# Try importing PyQt5
try:
    from PyQt5 import QtWidgets
    GUI_AVAILABLE = True
except ImportError:
    GUI_AVAILABLE = False

from truthbot_core import TruthBotCore

def run_cli(core):
    print('Running in CLI mode. Enter text to analyze (empty line to exit):')
    while True:
        text = input('> ')
        if not text.strip():
            break
        results = core.analyze_text(text)
        print('Results:', results)

if GUI_AVAILABLE:
    class MainWindow(QtWidgets.QMainWindow):
        def __init__(self, core):
            super().__init__()
            self.core = core
            self.setWindowTitle('TruthBot')
            self.text_edit = QtWidgets.QTextEdit(self)
            self.setCentralWidget(self.text_edit)
            button = QtWidgets.QPushButton('Analyze', self)
            button.clicked.connect(self.run_analysis)
            toolbar = self.addToolBar('Main')
            toolbar.addWidget(button)

        def run_analysis(self):
            text = self.text_edit.toPlainText()
            results = self.core.analyze_text(text)
            QtWidgets.QMessageBox.information(self, 'Results', str(results))

    def launch_gui(core):
        app = QtWidgets.QApplication(sys.argv)
        mw = MainWindow(core)
        mw.show()
        sys.exit(app.exec_())
else:
    def launch_gui(core):
        print('GUI not available; falling back to CLI.')
        run_cli(core)

if __name__ == '__main__':
    config = {'log_level': 'DEBUG'}
    core = TruthBotCore(config)
    launch_gui(core)
