
import os
import json
import logging
import nltk
import re

# Set NLTK data path relative to package
NLTK_DATA_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'nltk_data'))
os.environ.setdefault('NLTK_DATA', NLTK_DATA_PATH)

def check_environment():
    issues = []
    # Check punkt tokenizer
    try:
        nltk.data.find('tokenizers/punkt')
    except LookupError:
        issues.append('Missing NLTK punkt tokenizer.')
    # Check PyQt5 availability
    try:
        import PyQt5  # noqa: F401
    except ImportError:
        issues.append('Missing PyQt5 GUI package.')
    # Write issues to log
    log_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'logs'))
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, 'install_issues.log')
    with open(log_path, 'w') as log_file:
        for issue in issues:
            log_file.write(issue + '\n')
    return issues

class TruthBotCore:
    def __init__(self, config):
        self.config = config
        log_level = config.get('log_level', 'INFO')
        logging.basicConfig(level=getattr(logging, log_level))
        # Pre-flight environment check
        self.issues = check_environment()
        if self.issues:
            logging.warning('Environment issues detected: %s', self.issues)

    def analyze_text(self, text):
        # Tokenization with fallback
        try:
            tokens = nltk.word_tokenize(text)
        except LookupError:
            tokens = re.findall(r"\b\w+\b", text)
        # Compute simple metrics as placeholders
        e1 = self.compute_li_e1(text)
        o1 = self.compute_li_o1(text)
        hp = (e1 + o1) / 2
        return {'LI-E1': e1, 'LI-O1': o1, 'HP': hp}

    def compute_li_e1(self, text):
        # offline sentiment placeholder
        return 0.5

    def compute_li_o1(self, text):
        # offline complexity placeholder
        return 0.5
