import json
from pathlib import Path

SOS_DB = Path("knowledge_base/sos_log")
SOS_DB.mkdir(parents=True, exist_ok=True)
sos_file = SOS_DB / "log.sos.json"

def save_sos_entry(text, hp_score, deductions, flags):
    entry = {"text": text, "hp_score": hp_score, "deductions": deductions, "flags": flags}
    data = []
    if sos_file.exists():
        data = json.loads(sos_file.read_text())
    data.append(entry)
    sos_file.write_text(json.dumps(data, indent=2))

def load_sos_log():
    if sos_file.exists():
        return json.loads(sos_file.read_text())
    return []