# Casual Reform Indexer
# Archives low HP statements for transformation and symbolic reframing

import json
from pathlib import Path

REFORM_DB = Path("knowledge_base/casual_reform")  # ensure this dir exists

def save_low_hp_entry(input_text, hp_score, deductions, flags):
    entry = {
        "input": input_text,
        "hp_score": hp_score,
        "deductions": deductions,
        "flags": flags
    }
    REFORM_DB.mkdir(parents=True, exist_ok=True)
    index_file = REFORM_DB / "low_hp_log.json"
    data = []
    if index_file.exists():
        data = json.loads(index_file.read_text())
    data.append(entry)
    index_file.write_text(json.dumps(data, indent=2))