# Truthbot SCOS GUI - Self-Hosted Symbolic Cognition System

This is the self-contained version of Truthbot SCOS, designed for deployment on USB drives, private servers, or air-gapped systems.

## 🔧 Setup Instructions

### 🐳 Docker (Recommended for Standalone Hosting)

1. Build the container:
   docker build -t truthbot-scos .

2. Run the container:
   docker run -p 8501:8501 truthbot-scos

3. Open in browser:
   http://localhost:8501

---

## 📦 Features:
- SIIP/HP scoring with symbolic awareness
- `.sos` memory files saved locally (portable)
- Self-contained Streamlit GUI
- Expandable with your own `.vsip.json` or plugin modules

## 💡 USB / Offline Use:
Truthbot can be run from USB or external drives by:
- Cloning or extracting this folder
- Installing Python 3.10+
- Running: `streamlit run streamlit_app.py`

All logs and `.sos` files are saved locally inside `knowledge_base/`.