import streamlit as st
from casual_reform_indexer import save_low_hp_entry
from obscured_truth_detector import detect_hidden_elements
from truth_rephraser import suggest_rephrase
from fractal_resonance import get_resonance_factors
from sos_memory import save_sos_entry, load_sos_log

st.set_page_config(layout="wide")
st.title("Truthbot SCOS: Symbolic Cognition OS Interface")

tabs = st.tabs(["🧠 Core Deduction", "🔍 Low HP Insights", "🔧 Reframer", "🕳️ Hidden Suppression", "📜 SOS Memory"])

# Tab 1: Core Deduction (mockup logic)
with tabs[0]:
    st.header("🧠 Core Deduction")
    text = st.text_area("Enter input statement:")
    if st.button("Run Deduction", key="deduct"):
        # placeholder HP logic
        hp = 0.42 if "obedience" in text else 0.75
        deductions = ["Detected trauma phrase" if "silence" in text else "No trauma detected"]
        st.markdown(f"**HP Score:** {hp}")
        st.markdown(f"**Deductions:** {deductions}")
        save_sos_entry(text, hp, deductions, [])

# Tab 2: Low HP Logging
with tabs[1]:
    st.header("🔍 Low HP Insights")
    sos = load_sos_log()
    low_hp = [s for s in sos if s['hp_score'] < 0.5]
    for entry in low_hp:
        st.write(entry)

# Tab 3: Truth Rephraser
with tabs[2]:
    st.header("🔧 Truth Rephrasing")
    input_text = st.text_input("Low HP Statement:")
    if st.button("Suggest Rephrase"):
        st.write("🔁", suggest_rephrase(input_text))

# Tab 4: Concealed Truth
with tabs[3]:
    st.header("🕳️ Obscured Truth Detector")
    htext = st.text_area("Enter suspicious phrase:")
    if st.button("Detect Hidden Issues"):
        results = detect_hidden_elements(htext)
        st.write("⚠️ Flags:", results)

# Tab 5: SOS Log Review
with tabs[4]:
    st.header("📜 SOS Memory Browser")
    for entry in load_sos_log():
        st.json(entry)