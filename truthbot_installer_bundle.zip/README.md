# TruthBot

Analyze text for sentiment, entity recognition, and 'hedge' detection.

## Installation

Install the latest TruthBot in one step:

```bash
pip install git+https://github.com/yourrepo/truthbot.git
```

Alternatively, for offline or custom installs, download this bundle and run:

```bash
pip install .
```

## Usage

- **CLI**: `truthbot-cli --help`
- **GUI**: `truthbot-gui`

Enjoy!
