from setuptools import setup, find_packages
from setuptools.command.install import install
import subprocess
import sys

class PostInstallCommand(install):
    """Post-installation: download NLTK data & spaCy model."""
    def run(self):
        install.run(self)
        try:
            import nltk
            nltk.download("vader_lexicon", quiet=True)
            print("✅ NLTK vader_lexicon downloaded.")
        except Exception as e:
            print(f"⚠️ Failed to download NLTK data: {e}", file=sys.stderr)
        try:
            subprocess.check_call([sys.executable, "-m", "spacy", "download", "en_core_web_sm"])
            print("✅ spaCy en_core_web_sm model installed.")
        except Exception as e:
            print(f"⚠️ Failed to install spaCy model: {e}", file=sys.stderr)

setup(
    name="truthbot",
    version="0.1.0",
    author="Your Name",
    author_email="you@example.com",
    description="Analyze text for honesty, intent, and clarity",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourrepo/truthbot",
    packages=find_packages(),
    install_requires=[
        "nltk>=3.6",
        "spacy>=3.0",
        "PyQt5>=5.15",
        "pandas>=1.1",
        "numpy>=1.19"
    ],
    cmdclass={
        'install': PostInstallCommand,
    },
    entry_points={
        "console_scripts": [
            "truthbot-cli=truthbot.cli:main",
            "truthbot-gui=truthbot.gui:main"
        ],
    },
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
