# li_hp_logic.py
# Logic engine for HP/LI scoring system

def li_score(text: str, profile: str = "neutral"):
    factual_signals = ["confirmed", "evidence", "studies show"]
    fact_hits = sum(text.lower().count(word) for word in factual_signals)
    factual_consistency = min(1.0, fact_hits / 5)

    deceptive_patterns = ["allegedly", "might", "reportedly"]
    deception_hits = sum(text.lower().count(word) for word in deceptive_patterns)
    deception_heuristics = max(0, 1 - (deception_hits / 5))

    rhetorical_framing = max(0, 1 - (sum(text.lower().count(w) for w in ["heroic", "evil", "shocking"]) / 4))
    source_diversity = min(1.0, sum(text.lower().count(w) for w in ["critics", "alternative"]) / 3)
    epistemic_humility = min(1.0, sum(text.lower().count(w) for w in ["may be", "unclear"]) / 3)

    weights = {
        "neutral": {
            "factual_consistency": 0.25,
            "deception_heuristics": 0.25,
            "rhetorical_framing": 0.2,
            "source_diversity": 0.15,
            "epistemic_humility": 0.15
        }
    }[profile]

    hp_score = sum([
        factual_consistency * weights["factual_consistency"],
        deception_heuristics * weights["deception_heuristics"],
        rhetorical_framing * weights["rhetorical_framing"],
        source_diversity * weights["source_diversity"],
        epistemic_humility * weights["epistemic_humility"],
    ]) * 100

    return {
        "factual_consistency": factual_consistency,
        "deception_heuristics": deception_heuristics,
        "rhetorical_framing": rhetorical_framing,
        "source_diversity": source_diversity,
        "epistemic_humility": epistemic_humility,
        "HP_Score": round(hp_score, 2)
    }
