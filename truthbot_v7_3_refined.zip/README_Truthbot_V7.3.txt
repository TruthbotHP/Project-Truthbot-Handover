
TruthBot V7.3 — Refined HP/SIIP Engine

✅ Includes:
- truthbot_core.py — symbolic deduction engine
- assumption_engine.py — multi-symbol logic
- li_scorecard.py — linguistic indicators
- macros.py, message_object.py — scoring + memory systems
- truthbot_gui.py — multi-tab browser-compatible layout
- admin_gui.py — admin-only control layer

🌐 Browser Compatibility Plan:
- Use truthbot_gui.py to launch Flask or Streamlit-based UI
- Prepare split-pane layouts using iframe/grid/tab navigation
- Add socket or WebWorker support for multi-window coordination

💡 Stub logic shells from v7.2 are preserved for incremental plugin wiring (LLM, audio, CLI).
