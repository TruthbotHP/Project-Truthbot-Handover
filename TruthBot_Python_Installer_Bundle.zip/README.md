# TruthBot Manual (Integrated)
Welcome to TruthBot. This AI system helps analyze language for honesty, intent, and clarity.

## Features:
- HP & LI scoring
- Fraud detection support
- Modular plugin system
- Scalable GUI and CLI tools

Refer to the full documentation in the /docs folder.
