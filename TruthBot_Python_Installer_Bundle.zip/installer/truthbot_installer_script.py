# installer/truthbot_installer_script.py
import os
import subprocess

print("Installing TruthBot dependencies...")
subprocess.call(["pip", "install", "-r", "requirements.txt"])
print("Setup complete.")
