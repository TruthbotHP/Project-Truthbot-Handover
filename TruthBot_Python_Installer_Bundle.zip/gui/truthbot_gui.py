# gui/truthbot_gui.py
import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel

class TruthBotGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("TruthBot Interface")
        self.setGeometry(100, 100, 600, 400)
        self.label = QLabel("Welcome to TruthBot!", self)
        self.label.move(200, 180)

app = QApplication(sys.argv)
window = TruthBotGUI()
window.show()
sys.exit(app.exec_())
