# core/truthbot_core.py
class TruthBotCore:
    def __init__(self):
        print("TruthBot Core initialized")

    def analyze_text(self, text):
        return {"hp_score": 0.85, "li_flags": ["emotionally charged", "vague claims"]}
