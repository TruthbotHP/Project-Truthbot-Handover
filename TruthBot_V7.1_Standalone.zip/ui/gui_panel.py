# gui_panel.py
# GUI panel with LI + HP score evaluation display

import tkinter as tk
from tkinter import ttk

def launch_gui():
    root = tk.Tk()
    root.title("TruthBot HP/LI Evaluator")
    root.geometry("600x400")
    
    ttk.Label(root, text="Enter Text for Analysis:", font=("Arial", 12)).pack(pady=10)
    input_text = tk.Text(root, height=10, wrap="word")
    input_text.pack(padx=10, pady=5, fill="both", expand=True)

    result_label = ttk.Label(root, text="", font=("Arial", 10), foreground="blue")
    result_label.pack(pady=10)

    def analyze():
        text = input_text.get("1.0", "end-1c")
        from core.li_hp_logic import li_score
        results = li_score(text, profile="neutral")
        score_text = "\n".join([f"{k}: {round(v * 100) if k != 'HP_Score' else v}" for k, v in results.items()])
        result_label.config(text=score_text)

    ttk.Button(root, text="Evaluate", command=analyze).pack(pady=10)
    root.mainloop()
