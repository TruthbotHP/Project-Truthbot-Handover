
import tkinter as tk
from tkinter import ttk, messagebox
from truthbot.llm_plugins import sentiment_plugin, math_plugin, qa_plugin
from truthbot.utils import run_diagnostic_pass

class TruthBotGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("TruthBot V5 GUI Shell")
        self.geometry("600x400")

        self.input_label = ttk.Label(self, text="Enter your prompt:")
        self.input_label.pack(pady=5)

        self.text_input = tk.Text(self, height=6)
        self.text_input.pack(padx=10, pady=5, fill=tk.X)

        self.submit_button = ttk.Button(self, text="Submit", command=self.process_input)
        self.submit_button.pack(pady=10)

        self.output_label = ttk.Label(self, text="Output:")
        self.output_label.pack(pady=5)

        self.output_text = tk.Text(self, height=10)
        self.output_text.pack(padx=10, pady=5, fill=tk.BOTH)

    def process_input(self):
        user_input = self.text_input.get("1.0", tk.END).strip()
        if not user_input:
            messagebox.showwarning("Input Required", "Please enter a prompt.")
            return

        sentiment = sentiment_plugin.analyze_sentiment(user_input)
        try:
            math_result = math_plugin.solve_math(user_input)
        except:
            math_result = "N/A"
        answer = qa_plugin.answer_question(user_input)

        result = f"Sentiment: {sentiment}
Math Result: {math_result}
Answer: {answer}"
        self.output_text.delete("1.0", tk.END)
        self.output_text.insert(tk.END, result)


if __name__ == '__main__':
    TruthBotGUI().mainloop()