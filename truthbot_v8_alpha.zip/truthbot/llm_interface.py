
def call_local_llm(prompt):
    return f"[Local LLM] Response to: {prompt}"

def call_remote_llm(prompt):
    return f"[Remote LLM Placeholder] Response to: {prompt}"

def try_llm(prompt, allow_remote=True):
    try:
        return call_local_llm(prompt)
    except Exception as local_error:
        if allow_remote:
            return call_remote_llm(prompt)
        return f"[LLM Error] {local_error}"
