
def analyze_sentiment(text):
    """Simple stub for sentiment analysis."""
    if any(word in text.lower() for word in ['love', 'great', 'happy']):
        return "Positive"
    elif any(word in text.lower() for word in ['hate', 'bad', 'angry']):
        return "Negative"
    return "Neutral"
