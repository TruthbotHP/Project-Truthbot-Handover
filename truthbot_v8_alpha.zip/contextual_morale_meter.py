# Contextual Morale Meter: Detects emotional drift based on symbolic patterns

def morale_score(sos_entries):
    tension, empathy = 0, 0
    for entry in sos_entries:
        if "suppression" in entry["deductions"]:
            tension += 1
        if "truth" in entry["deductions"]:
            empathy += 1
    return {"tension": tension, "empathy": empathy, "balance": empathy - tension}