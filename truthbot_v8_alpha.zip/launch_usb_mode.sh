#!/bin/bash
echo "[TRUTHBOT LIVE OS] Boot sequence initiated..."
cd /truthbot
streamlit run streamlit_app.py --server.enableCORS=false