#!/usr/bin/env python3

def test_truthbot_environment():
    import os
    import sys
    try:
        import streamlit
        print("✅ Streamlit is installed")
        assert os.path.exists("streamlit_app.py")
        print("✅ GUI app is present")
        return True
    except Exception as e:
        print("❌ Environment error:", e)
        return False

if __name__ == "__main__":
    print("Running Truthbot SCOS Diagnostic...")
    test_truthbot_environment()