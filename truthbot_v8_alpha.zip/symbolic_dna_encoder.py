# Symbolic DNA Encoder: Creates fractal-coded symbolic strings for long-term recovery

def encode_dna(symbols):
    return "-".join([s[:2].upper() + str(len(s)) for s in symbols])

def decode_dna(code):
    parts = code.split("-")
    return [p[:-1].lower() for p in parts if len(p) > 2]