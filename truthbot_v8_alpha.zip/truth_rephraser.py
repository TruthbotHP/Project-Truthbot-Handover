# Truth Re-Phrasing Module
# Suggests alternatives for low-HP statements

def suggest_rephrase(original, context_terms=[]):
    return original.replace("obedience", "cooperation").replace("sacred duty", "chosen task")