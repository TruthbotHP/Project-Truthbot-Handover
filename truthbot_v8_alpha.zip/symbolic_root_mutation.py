# Symbolic Root Mutation Mode: Mutates symbol weightings based on deep trauma history

def mutate_root_weights(symbol_profile):
    mutated = {}
    for symbol, weight in symbol_profile.items():
        if "obedience" in symbol or "sacrifice" in symbol:
            mutated[symbol] = round(weight * 0.5, 2)
        else:
            mutated[symbol] = round(weight * 1.1, 2)
    return mutated