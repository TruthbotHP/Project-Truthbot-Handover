
#!/bin/bash
python3 -m venv truthbot_env
source truthbot_env/bin/activate
pip install -r requirements.txt
python3 - <<EOF
from src.truthbot_core import TruthBotCore
core = TruthBotCore({'log_level':'INFO'})
print(core.analyze_text("testing", features=['assumption_cascade','extended_li']))
EOF
