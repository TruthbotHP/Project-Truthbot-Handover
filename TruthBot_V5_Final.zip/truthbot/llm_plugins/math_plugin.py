
def solve_math(expression):
    """Simple math solver stub."""
    try:
        return eval(expression, {"__builtins__": {}}, {})
    except Exception as e:
        return f"Error: {e}"
