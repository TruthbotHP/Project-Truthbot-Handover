

def test_fallback():
    core = TruthBotCore()
    result = core.analyze_with_model("Is this true?")
    assert isinstance(result, str) and len(result) > 0


def test_analyze_text_returns_dict():
    core = TruthBotCore()
    res = core.analyze_text("This is a simple test.")
    assert isinstance(res, dict)
    assert "sentiment" in res and "hedge_ratio" in res and "entities" in res
