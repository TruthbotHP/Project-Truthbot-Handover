from PyQt5.QtWidgets import QApplication, QMainWindow, QTextEdit, QPushButton, QVBoxLayout, QWidget

def analyze(text):
    return {"summary": "Simulated analysis of: " + text[:50]}

class TruthBotGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("TruthBot Multi-Agent GUI")
        self.setGeometry(100, 100, 600, 400)

        self.text_edit = QTextEdit()
        self.analyze_button = QPushButton("Analyze")
        self.analyze_button.clicked.connect(self.on_analyze)

        layout = QVBoxLayout()
        layout.addWidget(self.text_edit)
        layout.addWidget(self.analyze_button)

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

    def on_analyze(self):
        text = self.text_edit.toPlainText()
        result = analyze(text)
        self.text_edit.setText(str(result))

def main():
    import sys
    app = QApplication(sys.argv)
    window = TruthBotGUI()
    window.show()
    sys.exit(app.exec_())
