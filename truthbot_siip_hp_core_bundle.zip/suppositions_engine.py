# Supposition Generator with SIP-based multi-symbol logic

def generate_suppositions_sip(symbols: List[str], weights: Dict[str, float]) -> List[Dict]:
    suppositions = []
    for sym in symbols:
        sip = load_symbol_sip(sym)
        base_hp = round(0.5 + weights.get(sym, 0.5) / 2, 2)
        trauma_supposition = None

        if sip:
            if sip.get("trauma_index", 0) > 0.8 or sip.get("historical_suppression", 0) > 0.8:
                trauma_supposition = {
                    "text": f"Symbol '{sym}' suggests coercion, trauma, or suppression context.",
                    "hp": base_hp,
                    "siip_lead": sym
                }

        # Default supposition
        default_supposition = {
            "text": f"Supposition about {sym}",
            "hp": base_hp,
            "siip_lead": sym
        }

        suppositions.append(default_supposition)
        if trauma_supposition:
            suppositions.append(trauma_supposition)

    return suppositions