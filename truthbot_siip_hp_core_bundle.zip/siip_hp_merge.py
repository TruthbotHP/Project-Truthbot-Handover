# SIIP HP Merge with dynamic SIP integration

def siip_hp_merge_sip_v1(text: str, trauma_adjustment=True) -> Dict:
    indicators = compute_linguistic_indicators(text)
    symbols = detect_symbols_v2(text)
    hp_base = compute_base_hp(indicators)
    hp_final = apply_trauma_adjustment_sip(hp_base, indicators, symbols) if trauma_adjustment else hp_base

    weights = compute_siip_weights(symbols)
    suppositions = generate_suppositions_sip(symbols, weights)
    deductions = generate_deductions(indicators, suppositions)
    triggered_suppositions = run_supposition_trigger_v2(suppositions, is_trauma_sensitive_v2)
    truth_flag = detect_truth_flag(triggered_suppositions)

    return {
        "input_text": text,
        "hp_score": hp_final,
        "indicators": indicators,
        "symbols": symbols,
        "weights": weights,
        "suppositions": triggered_suppositions,
        "deductions": deductions,
        "truth_flag": truth_flag
    }