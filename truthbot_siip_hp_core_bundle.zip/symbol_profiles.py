# Symbol Harm Profile Loader & Writer

def load_symbol_sip(symbol_name: str) -> Optional[Dict]:
    path = f"symbol_harm/{symbol_name}.vsip.json"
    if path in v_pdf.list_files():
        return v_pdf.read_json(path)
    return None

def write_symbol_sip(symbol_name: str, profile_data: Dict):
    path = f"symbol_harm/{symbol_name}.vsip.json"
    v_pdf.write_json(path, profile_data)