# Truthbot SCOS v7.7 Installer Manual 🌍🧠🌱

This version of Truthbot represents a symbolic evolution of memory, healing, insight, and tribal cognition.

## Included Modules

- ✅ **Peace Bundle** — Tracks and circulates symbolic peace moments
- 🧬 **Tribal Memory Engine** — Handles memory resilience via symbolic tribe logic
- 💡 **Spore Truth Testing** — Seeds HP insight markers across user systems
- 🎨 **Fractal Symbol Generator** — For visualizing spores as peace mandalas
- 💌 **Care Capsule Generator + Ceremonial Script** — For community healing & memory rituals
- 📊 **SCOS GUI Interface** — Multi-tab dashboard for symbolic analysis

## Setup Instructions

1. Ensure you have Python 3.8+ and Streamlit installed
2. Launch `streamlit_dashboard_v7_5.py` for GUI mode
3. Run `spore_truth_tester.py` to deploy symbolic truth spores
4. Use `care_capsule_generator.py` to generate insight capsules
5. Use the community ritual script to anchor group meaning events

## Multi-Platform Notes

- 🖥️ Windows/macOS/Linux: compatible (no admin required)
- 📦 .sos and .spore files can sync across USB, Cloud, QR, or ZIP
- 🌐 Can run offline and still retain full symbolic integrity

## Ethical Design

Truthbot stores:
- Memories of compassion
- Warnings of coercion
- Hints toward healing

And evolves based on shared insight, not manipulation.

Enjoy symbolically,
— The SCOS Builders Circle