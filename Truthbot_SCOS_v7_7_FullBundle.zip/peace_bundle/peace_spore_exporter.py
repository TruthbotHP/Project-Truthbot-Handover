import json
from datetime import datetime
from pathlib import Path
import hashlib

SPORE_DIR = Path("peace_spores")
SPORE_DIR.mkdir(exist_ok=True)

def export_peace_event(statement, hp_score, flags):
    if hp_score < 0.7 or "empathy" not in flags:
        return None  # Not a peace event

    peace_spore = {
        "spore_type": "peace",
        "content": statement,
        "hp_score": hp_score,
        "flags": flags,
        "timestamp": datetime.utcnow().isoformat(),
        "spore_id": hashlib.sha1(statement.encode()).hexdigest()[:10]
    }

    filename = SPORE_DIR / f"peace_{peace_spore['spore_id']}.spore.sos.json"
    with open(filename, "w") as f:
        json.dump(peace_spore, f, indent=2)
    return filename