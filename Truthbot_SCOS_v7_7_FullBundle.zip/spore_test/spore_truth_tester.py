import os
import json
import hashlib
from datetime import datetime

# Root directory for symbolic spore deployment
DEFAULT_SCAN_PATH = os.path.expanduser("~/Documents")

def compute_hp_signature(text):
    # Very basic symbolic honesty estimator placeholder
    hp = 0.7 if "freedom" in text else 0.3 if "obedience" in text else 0.5
    return round(hp, 2)

def generate_spore_file(folder_path, notes):
    payload = {
        "folder": folder_path,
        "notes": notes,
        "hp_signature": compute_hp_signature(" ".join(notes)),
        "timestamp": datetime.utcnow().isoformat(),
        "spore_id": hashlib.md5(folder_path.encode()).hexdigest()[:8]
    }
    spore_file = os.path.join(folder_path, "truth_spore.sos.json")
    try:
        with open(spore_file, "w") as f:
            json.dump(payload, f, indent=2)
        print(f"🧬 Spore placed at {spore_file}")
    except Exception as e:
        print(f"❌ Could not create spore in {folder_path}:", e)

def run_system_truth_test(scan_path=DEFAULT_SCAN_PATH):
    print(f"🔎 Scanning {scan_path} for symbolic nesting...")
    for root, dirs, files in os.walk(scan_path):
        if "symbol" in root.lower() or "law" in root.lower():
            notes = ["Observed symbolic density", "Check for coercion-framing or silence"]
            generate_spore_file(root, notes)

if __name__ == "__main__":
    run_system_truth_test()