import hashlib
from PIL import Image, ImageDraw

def generate_spore_fractal(spore_id, size=256):
    hash_digest = hashlib.sha256(spore_id.encode()).hexdigest()
    img = Image.new("RGB", (size, size), "white")
    draw = ImageDraw.Draw(img)

    for i in range(0, len(hash_digest), 2):
        x = (i * 10) % size
        y = (int(hash_digest[i:i+2], 16) % size)
        color = "#" + hash_digest[i:i+6]
        draw.ellipse([x, y, x+20, y+20], fill=color)

    file_path = f"fractal_spore_{spore_id[:6]}.png"
    img.save(file_path)
    return file_path