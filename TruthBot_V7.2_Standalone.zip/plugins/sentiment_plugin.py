
# sentiment_plugin.py
def analyze_sentiment(text):
    return {"sentiment": "neutral", "score": 0.5}
