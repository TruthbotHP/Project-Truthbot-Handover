# TruthBot

Analyze text for sentiment, entity recognition, and hedging indicators.

## Installation

Unzip and from inside the folder, run:

```bash
pip install .
```

This installs the package, dependencies, and required NLP models.

## Usage

- `truthbot-cli "your sentence here"`
- `truthbot-gui` launches the desktop app.
