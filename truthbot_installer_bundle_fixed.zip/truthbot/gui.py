import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel, QTextEdit, QPushButton, QVBoxLayout, QWidget
from truthbot.core import TruthBotCore

class TruthBotGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("TruthBot Interface")
        self.setGeometry(100, 100, 600, 500)
        self.core = TruthBotCore()

        self.input = QTextEdit(self)
        self.input.setPlaceholderText("Enter text to analyze…")
        self.button = QPushButton("Analyze", self)
        self.button.clicked.connect(self.on_analyze)
        self.output = QLabel("", self)
        self.output.setWordWrap(True)

        container = QWidget()
        layout = QVBoxLayout()
        layout.addWidget(self.input)
        layout.addWidget(self.button)
        layout.addWidget(self.output)
        container.setLayout(layout)
        self.setCentralWidget(container)

    def on_analyze(self):
        text = self.input.toPlainText().strip()
        if not text:
            self.output.setText("Please enter some text first.")
            return
        result = self.core.analyze_text(text)
        display = (
            f"Sentiment: {result['sentiment']}\n"
            f"Hedge Ratio: {result['hedge_ratio']}\n"
            f"Entities: {result['entities']}"
        )
        self.output.setText(display)

def main():
    app = QApplication(sys.argv)
    window = TruthBotGUI()
    window.show()
    sys.exit(app.exec_())
