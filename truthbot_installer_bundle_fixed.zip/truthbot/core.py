import nltk
import spacy
from nltk.sentiment import SentimentIntensityAnalyzer

nltk.download("vader_lexicon", quiet=True)
nlp = spacy.load("en_core_web_sm")

class TruthBotCore:
    def __init__(self):
        self.sia = SentimentIntensityAnalyzer()

    def analyze_text(self, text: str):
        sent = self.sia.polarity_scores(text)
        doc = nlp(text)
        entities = [(ent.text, ent.label_) for ent in doc.ents]
        hedges = {"maybe", "could", "possibly", "perhaps"}
        tokens = {tok.lower_ for tok in doc}
        hedge_count = sum(1 for w in tokens if w in hedges)
        hedge_ratio = hedge_count / max(len(tokens), 1)
        return {
            "sentiment": sent,
            "entities": entities,
            "hedge_ratio": round(hedge_ratio, 3)
        }
