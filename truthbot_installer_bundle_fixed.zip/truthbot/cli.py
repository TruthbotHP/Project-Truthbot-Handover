import argparse
from truthbot.core import TruthBotCore

def main():
    parser = argparse.ArgumentParser(prog="truthbot-cli")
    parser.add_argument("text", nargs="+", help="Text to analyze")
    args = parser.parse_args()
    core = TruthBotCore()
    text = " ".join(args.text)
    result = core.analyze_text(text)
    print("=== TruthBot Analysis ===")
    print(f"Sentiment: {result['sentiment']}")
    print(f"Hedge Ratio: {result['hedge_ratio']}")
    print(f"Entities: {result['entities']}")

if __name__ == "__main__":
    main()
