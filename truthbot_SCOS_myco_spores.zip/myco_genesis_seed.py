# Myco Genesis Seed: Reactivates spore memory in a symbolic-friendly environment

def rehydrate_spore(spore):
    if spore["status"] == "dormant":
        spore["status"] = "awakening"
        return spore["memory_payload"]
    return []