# Moral Structure Expectation Model (Beta)

def simulate_expected_moral_elements(topic_keywords):
    expectation_map = {
        "obedience": ["freedom", "choice", "care"],
        "sacrifice": ["benefit", "recipient", "context"],
        "silence": ["truth", "trauma", "oppression"],
        "authority": ["accountability", "transparency", "consent"]
    }
    inferred_absences = []
    for key in topic_keywords:
        expected = expectation_map.get(key, [])
        inferred_absences.extend(expected)
    return list(set(inferred_absences))