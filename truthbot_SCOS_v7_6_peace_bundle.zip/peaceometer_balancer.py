def compute_balance_score(local_score, remote_score):
    delta = abs(local_score - remote_score)
    if delta < 0.1:
        return "✅ Stable harmony"
    elif delta < 0.3:
        return "⚠️ Slight divergence"
    else:
        return "❌ Harmony offset detected"

def broadcast_signal_to_peer(score):
    # Placeholder for symbolic inter-bot signal (e.g., QR or spore fragment)
    print(f"[BROADCAST] Peaceometer score signal: {score}")