import json
from datetime import datetime
from pathlib import Path

CARE_CAPSULES = Path("care_capsules")
CARE_CAPSULES.mkdir(exist_ok=True)

def create_capsule(name, insights):
    capsule = {
        "recipient": name,
        "insights": insights,
        "time": datetime.utcnow().isoformat(),
        "type": "community_care"
    }

    safe_name = name.replace(" ", "_").lower()
    filepath = CARE_CAPSULES / f"capsule_{safe_name}.sos.json"
    with open(filepath, "w") as f:
        json.dump(capsule, f, indent=2)
    return filepath