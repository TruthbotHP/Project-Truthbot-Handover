from truthbot.core import TruthBotCore

def test_fallback():
    core = TruthBotCore()
    result = core.analyze_with_model("Is this true?")
    assert isinstance(result, str) and len(result) > 0
