import argparse
from truthbot.core import TruthBotCore

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--text", type=str, required=True, help="Text to analyze")
    parser.add_argument("--model-path", type=str, default="C:/Models/mistral.gguf", help="Path to .gguf model")
    args = parser.parse_args()

    core = TruthBotCore(model_path=args.model_path)
    print("=== Hybrid Analysis ===")
    print(core.analyze_with_model(args.text))

if __name__ == "__main__":
    main()
