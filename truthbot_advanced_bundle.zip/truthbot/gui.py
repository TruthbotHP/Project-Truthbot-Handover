import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QTextEdit, QPushButton, QLabel, QTabWidget
from truthbot.core import TruthBotCore

class AgentTab(QWidget):
    def __init__(self, model_path):
        super().__init__()
        self.core = TruthBotCore(model_path=model_path)
        layout = QVBoxLayout()
        self.input = QTextEdit()
        self.button = QPushButton("Analyze")
        self.output = QLabel()
        layout.addWidget(self.input)
        layout.addWidget(self.button)
        layout.addWidget(self.output)
        self.setLayout(layout)
        self.button.clicked.connect(self.analyze)

    def analyze(self):
        text = self.input.toPlainText()
        result = self.core.analyze_with_model(text)
        self.output.setText(result)

class TruthBotGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("TruthBot Multi-Agent GUI")
        self.setGeometry(100, 100, 800, 600)
        self.tabs = QTabWidget()
        for i in range(3):
            tab = AgentTab("C:/Models/mistral.gguf")
            self.tabs.addTab(tab, f"Agent {i+1}")
        self.setCentralWidget(self.tabs)

def main():
    app = QApplication(sys.argv)
    window = TruthBotGUI()
    window.show()
    sys.exit(app.exec_())
