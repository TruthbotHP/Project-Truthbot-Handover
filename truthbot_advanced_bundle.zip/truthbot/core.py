import os
import nltk
import spacy
import requests
from llama_cpp import Llama
from nltk.sentiment import SentimentIntensityAnalyzer

nltk.download("vader_lexicon", quiet=True)
nlp = spacy.load("en_core_web_md")

class TruthBotCore:
    def __init__(self, model_path="C:/Models/mistral.gguf"):
        self.model_path = model_path
        self.sia = SentimentIntensityAnalyzer()
        try:
            self.llm = Llama(model_path=self.model_path, n_ctx=2048)
        except Exception as e:
            print(f"[Fallback] Failed to load LLaMA model: {e}")
            self.llm = None

    def analyze_text(self, text: str):
        sent = self.sia.polarity_scores(text)
        doc = nlp(text)
        entities = [(ent.text, ent.label_) for ent in doc.ents]
        hedges = {"maybe", "could", "possibly", "perhaps"}
        tokens = {tok.lower_ for tok in doc}
        hedge_count = sum(1 for w in tokens if w in hedges)
        hedge_ratio = hedge_count / max(len(tokens), 1)
        return {
            "sentiment": sent,
            "entities": entities,
            "hedge_ratio": round(hedge_ratio, 3)
        }

    def analyze_with_model(self, text: str, prompt_style="honesty"):
        prompt = f"Analyze this text for truthfulness, bias, and hedging:\n\n{text}\n\nAnalysis:"
        if self.llm:
            try:
                output = self.llm(prompt, max_tokens=256, stop=["\n\n"])
                return output["choices"][0]["text"].strip()
            except Exception as e:
                print(f"[Fallback] LLaMA call failed: {e}")
        return self.analyze_with_gpt4all(text, prompt_style)

    def analyze_with_gpt4all(self, text, prompt_style="honesty"):
        system_prompt = "You are an AI truth analyst. Analyze the following text."
        if prompt_style == "summary":
            system_prompt = "Summarize the text in 1–2 sentences."
        try:
            response = requests.post("http://localhost:4891/v1/chat/completions", json={
                "model": "mistral-7b",
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": text}
                ],
                "temperature": 0.7,
            })
            return response.json()["choices"][0]["message"]["content"]
        except Exception as e:
            return f"GPT4All fallback failed: {e}"
