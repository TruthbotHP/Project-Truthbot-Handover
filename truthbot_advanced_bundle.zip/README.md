# TruthBot Advanced

Offline AI assistant with:
- llama.cpp (`.gguf`) model support
- GPT4All fallback
- Multi-agent GUI
- CLI with dynamic model path

Usage:
- Install: `pip install .`
- CLI: `truthbot-cli --text "input" --model-path "C:/Models/mistral.gguf"`
- GUI: `truthbot-gui`
