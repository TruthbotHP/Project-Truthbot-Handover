# tribe_simulator.py
from tribal_memory_regulator import simulate_tribal_responses

def run_simulation(symbols, base_hp=0.5):
    results = {}
    for sym in symbols:
        responses = simulate_tribal_responses(sym, base_hp)
        results[sym] = responses
    return results