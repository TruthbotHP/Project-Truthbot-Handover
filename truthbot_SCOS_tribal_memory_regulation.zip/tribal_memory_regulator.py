import json
from datetime import datetime

# In-memory store for simulation
TRIBAL_RESPONDERS = {
    "empath": {"symbol_tilt": {"silence": -0.3, "empathy": 0.6}, "resonance_scope": ["care"]},
    "analyst": {"symbol_tilt": {"obedience": -0.6, "logic": 0.4}, "resonance_scope": ["coercion"]},
    "seer": {"symbol_tilt": {"sacrifice": -0.4, "myth": 0.5}, "resonance_scope": ["loss", "memory"]},
    "counterweight": {"symbol_tilt": {"obedience": 0.1, "sacrifice": 0.1}, "resonance_scope": ["risk", "doubt"]}
}

# 1:10 Responder Ratio
def simulate_tribal_responses(symbol, base_score):
    responders = []
    for tribe, props in TRIBAL_RESPONDERS.items():
        tilt = props["symbol_tilt"].get(symbol, 0)
        response_score = round(base_score + tilt, 2)
        responders.append({"tribe": tribe, "score": response_score})
    return responders

def regulate_memory_entry(entry):
    symbol = entry.get("key_symbol", "unknown")
    base_score = entry.get("hp_score", 0.5)
    votes = simulate_tribal_responses(symbol, base_score)

    avg = sum(v["score"] for v in votes) / len(votes)
    min_vote = min(v["score"] for v in votes)
    max_vote = max(v["score"] for v in votes)
    divergence = round(max_vote - min_vote, 3)

    decision = {
        "keep": avg > 0.4,
        "quarantine": divergence > 0.4,
        "override_needed": min_vote < 0.2
    }

    return {
        "tribal_scores": votes,
        "decision": decision,
        "timestamp": datetime.utcnow().isoformat()
    }