#!/bin/bash
echo "Installing TruthBot V7.1 for Linux..."
python3 -m venv truthbot_env
source truthbot_env/bin/activate
pip3 install -r requirements.txt
python3 ui/gui_panel.py
