# Spore Launcher: Packages .sos data into symbolic spores for storage or redeployment

import json
import hashlib

def create_spore(sos_entries, environment_tag="unknown"):
    hash_digest = hashlib.sha256(json.dumps(sos_entries).encode()).hexdigest()[:8]
    spore = {
        "id": f"spore_{hash_digest}",
        "origin_env": environment_tag,
        "memory_payload": sos_entries,
        "status": "dormant"
    }
    return spore

def save_spore(spore, path="spores/spore.sos.json"):
    with open(path, "w") as f:
        json.dump(spore, f, indent=2)