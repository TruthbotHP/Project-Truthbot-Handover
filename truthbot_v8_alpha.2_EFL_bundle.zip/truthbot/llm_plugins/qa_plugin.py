
def answer_question(question, context=None):
    """Basic stub for question answering."""
    return "This is a placeholder answer to your question."
