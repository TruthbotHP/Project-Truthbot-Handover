
import torch

def detect_capabilities():
    try:
        if torch.cuda.is_available():
            return {
                "GPU": torch.cuda.get_device_name(0),
                "CUDA Version": torch.version.cuda,
                "Torch": torch.__version__
            }
        else:
            return {"CPU": True, "Torch": torch.__version__}
    except ImportError:
        return {"Torch": "not installed"}
