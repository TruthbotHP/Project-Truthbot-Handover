
import os
import platform
import subprocess

def run_diagnostic_pass():
    """Run a diagnostic pass for system and syntax validation."""
    return {
        "os": platform.system(),
        "os_version": platform.version(),
        "python_version": platform.python_version(),
        "cwd": os.getcwd(),
        "env_check": "Passed" if os.environ else "Missing env"
    }

def model_probe(model_path: str) -> dict:
    """Stub to probe the presence and meta-info of a model file."""
    if not os.path.exists(model_path):
        return {"status": "not_found", "path": model_path}
    size = os.path.getsize(model_path)
    return {
        "status": "found",
        "path": model_path,
        "size_mb": round(size / (1024 * 1024), 2)
    }

def available_llm_plugins(directory: str = "llm_plugins"):
    """Lists available plugin files from the LLM plugin directory."""
    if not os.path.exists(directory):
        return []
    return [f for f in os.listdir(directory) if f.endswith(".py")]
