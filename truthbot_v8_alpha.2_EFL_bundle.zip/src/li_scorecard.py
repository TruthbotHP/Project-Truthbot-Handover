
class LI_Scorecard:
    """
    Encapsulates DMA-LI metrics, extended indices, and HP calculation.
    """
    def __init__(self, scores, weights=None):
        self.scores = scores  # dict of metric_name: raw_score
        self.weights = weights or {k:1 for k in scores}

    def honesty_probability(self):
        total = 0.0
        weight_sum = 0.0
        for k, v in self.scores.items():
            w = self.weights.get(k, 1)
            total += v * w
            weight_sum += w
        return total / weight_sum if weight_sum else 0.0
