
import os
import logging
import nltk
import re
from li_scorecard import LI_Scorecard
from task_manager import TaskManager
from macros import auto_enhance
from repair_agent import SelfRepairAgent
from plugins.mode_kernel.assumption_engine import test_assumption_chain
from message_object import MessageObject

# environment check omitted for brevity...

class TruthBotCore:
    def __init__(self, config):
        self.config = config
        self.task_manager = TaskManager()
        self.repair_agent = SelfRepairAgent(os.path.dirname(__file__))
        # ...

    def analyze_text(self, text, features=None):
        features = features or []
        results = {}
        # Always basic metrics
        msg = MessageObject(text)
        basic_scores = {
            'sentiment': msg.get_sentiment(),
            'drift': msg.calculate_linguistic_drift()
        }
        results.update(basic_scores)
        if 'assumption_cascade' in features:
            results['assumption_chain'] = test_assumption_chain(text)
        if 'extended_li' in features:
            # placeholder extended metrics
            sc = LI_Scorecard(basic_scores)
            results['hp'] = sc.honesty_probability()
        return results

    def analyze_care_data(self, text, profile, wc, features=None):
        # stub
        return self.analyze_text(text, features)

    def analyze_user_question(self, user_input, user_profile, features=None):
        # integrate previous diagnostic function, with feature toggles
        return self.analyze_text(user_input, features)

    def run_tasks(self, text):
        # register tasks based on config
        self.task_manager.register_task('li', self.analyze_text, text)
        return self.task_manager.run_all()
