
from PyQt5 import QtWidgets
import os

import json

SETTINGS_FILE = os.path.abspath(os.path.join(os.getcwd(), 'settings.json'))

def load_settings():
    try:
        with open(SETTINGS_FILE) as f:
            return json.load(f)
    except:
        return {}

def save_settings(settings):
    with open(SETTINGS_FILE, 'w') as f:
        json.dump(settings, f, indent=2)


class AdminDashboard(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('TruthBot Admin Dashboard')
        layout = QtWidgets.QVBoxLayout(self)

        tabs = QtWidgets.QTabWidget()
        tabs.addTab(self._diagnostics_tab(), 'Diagnostics')
        tabs.addTab(self._plugins_tab(), 'Plugins')
        tabs.addTab(self._macros_tab(), 'Macros')
        tabs.addTab(self._apikeys_tab(), 'API Keys')

        layout.addWidget(tabs)
        self.setLayout(layout)

    def _diagnostics_tab(self):
        w = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(w)
        log_path = os.path.join(os.getcwd(), 'logs', 'install_issues.log')
        text = QtWidgets.QTextEdit()
        text.setReadOnly(True)
        if os.path.isfile(log_path):
            text.setPlainText(open(log_path).read())
        else:
            text.setPlainText('No diagnostic log found.')
        v.addWidget(text)
        return w

    def _plugins_tab(self):
        w = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(w)
        v.addWidget(QtWidgets.QLabel('Plugin management coming soon'))
        return w

    def _macros_tab(self):
        w = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(w)
        v.addWidget(QtWidgets.QCheckBox('Inject try/except'))
        v.addWidget(QtWidgets.QCheckBox('Wrap with timer'))
        return w

    def _apikeys_tab(self):
        w = QtWidgets.QWidget()
        v = QtWidgets.QFormLayout(w)
        v.addRow('Fact-Check Key:', QtWidgets.QLineEdit())
        v.addRow('Moral-Framing Key:', QtWidgets.QLineEdit())
        v.addRow('Trauma-Service Key:', QtWidgets.QLineEdit())
        return w
