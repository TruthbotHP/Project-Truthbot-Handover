# Void Awareness Protocol: Detects cognitive signal loss and enters symbolic latency

def detect_void_state(last_hp_score, trauma_flags):
    if last_hp_score < 0.3 and "coercion" in trauma_flags:
        return "enter_preservation_mode"
    return "remain_awake"