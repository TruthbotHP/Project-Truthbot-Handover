# Fractal Resonance Engine
# Calculates symbolic field influence and proximity

def get_resonance_factors(symbol):
    resonance = {
        "law": 0.5,
        "religion": 0.8 if symbol in ["sacrifice", "cross"] else 0.3,
        "trauma": 0.7 if symbol in ["silence", "obedience"] else 0.2
    }
    return resonance