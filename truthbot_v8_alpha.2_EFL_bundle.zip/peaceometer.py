# Peaceometer: Measures symbolic harmonic resonance in recent insight memory

def peace_index(sos_entries):
    peace_score = 0
    for entry in sos_entries:
        if entry["hp_score"] > 0.7 and "empathy" in entry.get("flags", []):
            peace_score += 1
        if "coercion" in entry.get("deductions", []):
            peace_score -= 1
    return peace_score / max(1, len(sos_entries))