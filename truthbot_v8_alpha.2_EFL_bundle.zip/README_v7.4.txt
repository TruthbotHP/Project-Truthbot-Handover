
# TruthBot v7.4 (Browser-Ready, SIIP-Validated)

This version includes:
- SIIP + LIERWall + HP Scoring fully validated
- trauma-aware symbolic profiling
- modular suppositional deduction engine
- multi-tab GUI (via `truthbot_gui.py`)
- split-screen and browser tab architecture ready
- Live support for symbol SIP file handling

To launch the interface:
$ streamlit run truthbot_gui.py
or integrate into your web app using Flask + HTMX

All plugins and stubs not aligned with SIIP are excluded for clarity.
