
import tkinter as tk
from tkinter import messagebox
from truthbot_core import start_analysis

class TruthbotGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Truthbot GUI Interface")
        self.geometry("400x200")
        self.configure(bg="white")
        self.build_widgets()

    def build_widgets(self):
        label = tk.Label(self, text="Welcome to Truthbot", font=("Arial", 16), bg="white")
        label.pack(pady=20)
        analyze_button = tk.Button(self, text="Run Analysis", command=self.run_analysis)
        analyze_button.pack(pady=10)

    def run_analysis(self):
        try:
            result = start_analysis()
            messagebox.showinfo("Analysis Result", f"Result: {result}")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")

if __name__ == "__main__":
    app = TruthbotGUI()
    app.mainloop()
