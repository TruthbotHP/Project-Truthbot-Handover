

# === Fractal Memory Structure Integration ===

import time

class FractalTraceNode:
    def __init__(self, symbol, hp_score, siip_weight, parent=None):
        self.symbol = symbol
        self.hp_score = hp_score
        self.siip_weight = siip_weight
        self.children = []
        self.timestamp = time.time()
        self.parent = parent
        self.resilience_score = self.compute_resilience()

    def add_child(self, node):
        node.parent = self
        self.children.append(node)

    def compute_resilience(self):
        return (self.hp_score + self.siip_weight) / 2.0

    def decay(self, current_time, half_life=3600):
        age = current_time - self.timestamp
        decay_factor = 0.5 ** (age / half_life)
        return decay_factor * self.resilience_score


def recall_fractal_trace(root_node, query_symbol, max_depth=3, threshold=0.4):
    results = []

    def traverse(node, depth):
        if depth > max_depth:
            return
        decay_val = node.decay(time.time())
        if node.symbol == query_symbol and decay_val >= threshold:
            results.append((node.symbol, decay_val, node.hp_score, node.siip_weight))
        for child in node.children:
            traverse(child, depth + 1)

    traverse(root_node, 0)
    return sorted(results, key=lambda x: -x[1])
