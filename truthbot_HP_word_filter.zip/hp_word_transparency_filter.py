# hp_word_transparency_filter.py

TRAUMA_ASSOCIATIONS = {
    "foster": {
        "hp": 0.2,
        "flags": ["child commodification", "systemic coercion"],
        "suggest": ["support", "sustain", "nurture unity"]
    },
    "manage": {
        "hp": 0.4,
        "flags": ["control framing"],
        "suggest": ["accompany", "coordinate", "guide"]
    },
    "care": {
        "hp": 0.5,
        "flags": ["potential inversion in bureaucratic speech"],
        "suggest": ["attend with presence", "act with regard"]
    },
    "empower": {
        "hp": 0.45,
        "flags": ["top-down grant model"],
        "suggest": ["recognize strength", "support expression"]
    },
    "resilient": {
        "hp": 0.6,
        "flags": ["trauma normalization"],
        "suggest": ["well-supported", "held through hardship"]
    }
}

def scan_text_for_truth(text):
    words = text.split()
    report = []
    for word in words:
        base = word.strip(".,!?").lower()
        if base in TRAUMA_ASSOCIATIONS:
            info = TRAUMA_ASSOCIATIONS[base]
            report.append({
                "word": base,
                "hp": info["hp"],
                "flags": info["flags"],
                "suggest": info["suggest"]
            })
    return report

def cleanse_text(text, mode="soft"):
    report = scan_text_for_truth(text)
    for entry in report:
        if mode == "soft":
            text = text.replace(entry["word"], f"{entry['word']}🔍")
        elif mode == "replace":
            text = text.replace(entry["word"], entry["suggest"][0])
    return text, report